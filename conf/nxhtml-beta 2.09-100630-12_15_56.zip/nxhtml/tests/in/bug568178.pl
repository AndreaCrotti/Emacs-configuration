print SOCKET << HTML or warn "Cannot write to socket: $!";
<input type="text">html continues...

HTML
