<?php

include_once(APP_AAA_INCLUDE."bb.php");
include_once(APP_AAA_INCLUDE."cc.php");
include_once(APP_AAA_INCLUDE."dd.php");
include_once(APP_AAA_INCLUDE."ee.php");
include_once(APP_AAA_INCLUDE."ff.php");
include_once(APP_AAA_INCLUDE."gg.php");

class Test
{
	public $var1;

	function __construct()
	{
		$this->var1 = 5;
	}
}