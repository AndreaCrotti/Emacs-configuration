<?xml version="1.0" encoding="utf-8"?>
<map version="0.9.0">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node text="Test of org and mumamo">
<node style="bubble" background_color="#eeee00">
<richcontent TYPE="NODE"><html>
<head>
<style type="text/css">
<!--
p { margin-top: 0 }
-->
</style>
</head>
<body>
<p><br />  Below is a html chunk</p><p><br /></p>

<p>
  I have not idea of how to use this yet.
</p>
<p><br /></p>
</body>
</html>
</richcontent>
<richcontent TYPE="NOTE"><html><head></head><body><p>-- This is more about "Test of org and mumamo" --</p></body></html></richcontent>
</node>
<node text="Some subnode">
<node style="bubble" background_color="#eeee00">
<richcontent TYPE="NODE"><html>
<head>
<style type="text/css">
<!--
p { margin-top: 0 }
-->
</style>
</head>
<body>
<p><br />Hm, header lines are broken, why?</p>
</body>
</html>
</richcontent>
<richcontent TYPE="NOTE"><html><head></head><body><p>-- This is more about "Some subnode" --</p></body></html></richcontent>
</node>
</node>
</node>
</map>
